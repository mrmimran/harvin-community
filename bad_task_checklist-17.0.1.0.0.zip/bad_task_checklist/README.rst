**********************
**Task Checklist**
**********************

**Description**
***************

* Technical name: bad_task_checklist.

**Author**
**********

* BizzAppDev Systems Pvt. Ltd.

**Installation**
****************

* Under applications, the application bad_task_checklist can be installed/uninstalled.

**Configuration**
*****************

* #N/A

**Usage**
*********

* Added menu button called Task Checklists under configuration button in Project module.

* We can create new checklists and add different goals(checklist items) in it.

* There are different views like pivot view and group by to shortlist the checklists and checklist items according to different criteria.

* There is saperate Many2many field at task level is provided to choose the checklists for that particular task.

* By clicking the "complete" button we change state of checklist item into done and "Todo" button will make checklist item state in todo.

* Progress bar allow users to track the progress of checklists.

* User can use same checklists in different tasks that allow to track checklist progress.

**Known issues/Roadmap**
************************

* #N/A

**Changelog**
*************

* #N/A
